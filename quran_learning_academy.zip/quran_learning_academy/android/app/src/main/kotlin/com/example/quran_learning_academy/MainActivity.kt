package com.example.quran_learning_academy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
