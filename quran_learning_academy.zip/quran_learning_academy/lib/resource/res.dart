import 'package:quran_learning_academy/resource/web_colors.dart';

import 'images.dart';

class R {
  static AppColors colors = AppColors();
  static AppImages images = AppImages();
}
