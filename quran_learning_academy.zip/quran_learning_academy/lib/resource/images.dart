class AppImages {
  String heart = 'assets/images/heart.png';
  String Eas = 'assets/images/Eas.png';
  String easy1 = 'assets/images/Easy1.png';
  String female = 'assets/images/female.png';
  String hijab = 'assets/images/hijab.png';
  String boy = 'assets/images/boy.png';

  String eassy = 'assets/images/eassy.png';
  String a = 'assets/images/a.png';
  String Easy1 = 'assets/images/Easy1.png';
  String group = 'assets/images/group.png';
  String girl = 'assets/images/girl.png';
  String picture1 = 'assets/images/picture1.png';
  String picture2 = 'assets/images/picture2.png';
  String picture3 = 'assets/images/picture3.png';
  String picture4 = 'assets/images/picture4.png';
  String picture5 = 'assets/images/picture5.png';
  String picture6 = 'assets/images/picture6.png';
  String girl2 = 'assets/images/girl2.png';
  String man1 = 'assets/images/man1.png';
  String girl1 = 'assets/images/girl1.png';
  String man = 'assets/images/man.png';
}
